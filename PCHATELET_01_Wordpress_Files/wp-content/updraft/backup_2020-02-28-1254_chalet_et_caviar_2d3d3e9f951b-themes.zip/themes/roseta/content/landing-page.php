<?php
/**
 * This file handles landing page elements
 *
 * @package Roseta
 */

roseta_lpslider();
roseta_lpblocks();
roseta_lptext('one');
roseta_lpboxes(1);
roseta_lptext('two');
roseta_lpboxes(2);
roseta_lptext('three');
roseta_lpindex();
roseta_lptext('four');
		
// FIN